<p align="center">
    <img src="images/logo.png" width="480"\>
</p>

## tunga: Agile Text Analytics Platform
Projeyi tanitan basit ve etikleyici bir veya birkac cumle tam da burada olmali 

## Table of contents
1. Icindekileri
2. Buraya
3. Yazmaliyiz
4. Basliklar
5. Halinde

## Installation
```bash
docker pull <bizim docker containeri adi>:latest
veyahut
docker-compose up
```

## Sistem Diyagramı
<p align="center">
    <img src="images/tunga_system_diagram.png" width="480"\>
</p>

## Kullandığımız Kaynaklar
For deasciify methods : pip3 install git+https://github.com/emres/turkish-deasciifier.git

For asciify methods: git clone https://github.com/starlangsoftware/TurkishDeasciifier-Py.git

Turkish name list : https://gist.github.com/emrekgn/b4049851c88e328c065a

Stop word: https://github.com/ahmetax/trstop/blob/master/dosyalar/turkce-stop-words

Kufur tespit list: https://github.com/ooguz/turkce-kufur-karaliste/blob/master/karaliste.txt

For Summary : https://github.com/Eruimdas/turkish_text_summarization/blob/master/Extraction_Based_Text_Summarization.ipynb


