def translate(sentence):
    return "translated"