def translate(translate):
    return "google translate"